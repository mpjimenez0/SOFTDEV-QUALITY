

<footer id="footer">
        <div class="wrapper">
            <p style="color:white;">Copyright &copy; Camp Coordination and Camp Management 2017</p>
        </div>
 </footer>
