<?php
 $username = 'root';
 $password = '';
 $database = 'camp';
 /*$con = mysqli_connect($host,$username,$password);
mysqli_select_db($con,$database);*/
?>