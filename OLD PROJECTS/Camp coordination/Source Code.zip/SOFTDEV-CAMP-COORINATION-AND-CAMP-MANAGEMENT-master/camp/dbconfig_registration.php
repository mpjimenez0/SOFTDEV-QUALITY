<?php
$host = "localhost";
$user = "root";
$password = "Amielcuasay03!";
$database = "camp";
$con = mysqli_connect($host,$user,$password);
mysqli_select_db($con,$database);
?>
